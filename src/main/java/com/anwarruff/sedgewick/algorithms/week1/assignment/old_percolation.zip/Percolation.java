import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation
{
    private static final boolean OPEN = true;

    private static final int NUM_AUX_SITES = 2;
    private static final int TOP_AUX_SITE = 0;
    private static final int BOTTOM_AUX_SITE = 1;

    private enum Shift {UP, DOWN, LEFT, RIGHT}
    private int gridWidth;
    private boolean percolation;

    private boolean[][] stateGrid;
    private WeightedQuickUnionUF topDownGraph;
    private WeightedQuickUnionUF bottomUpGraph;

    private final int bottomRow;

    /**
     * Creates an NxN site grid, for percolation simulation.
     *
     * @param gridWidth square grid width
     */
    public Percolation(int gridWidth)
    {
        percolation = false;
        this.bottomRow = gridWidth - 1;
        this.gridWidth = gridWidth;
        if (gridWidth <= 0) {
            throw new IllegalArgumentException();
        }

        stateGrid = new boolean[gridWidth][gridWidth];
        topDownGraph = new WeightedQuickUnionUF(gridWidth * gridWidth + NUM_AUX_SITES);
        bottomUpGraph = new WeightedQuickUnionUF(gridWidth * gridWidth + NUM_AUX_SITES);
        for (int row = 0; row < gridWidth; ++row) {
            for (int col = 0; col < gridWidth; ++col) {
                stateGrid[row][col] = false;
            }
        }
    }

    /**
     * Opens the site specified by the row and column indices.
     * @param i row index
     * @param j column index
     * @throws IndexOutOfBoundsException
     */
    public void open(int i, int j)
    {
        openSite(i-1, j-1);
    }

    /**
     * Returns true if the site specified by the row and column index is open,
     * otherwise false.
     * @param i row index
     * @param j column index
     * @return boolean
     * @throws IndexOutOfBoundsException
     */
    public boolean isOpen(int i, int j)
    {
        return isSiteOpen(i-1, j-1);
    }

    /**
     * Returns true if the site specified by the row and column index is full,
     * otherwise false.
     * @param i
     * @param j
     * @return boolean
     * @throws IndexOutOfBoundsException
     */
    public boolean isFull(int i, int j)
    {
        return isSiteFull(i-1, j-1);
    }

    /**
     * Returns true if the one of the sites in the bottom row is full.
     * @return boolean
     */
    public boolean percolates()
    {
        return percolation;
    }

    public static void main(String[] args)
    {

    }

    /* --------------------------------------------------------------------------
     *                          Private Methods
     * --------------------------------------------------------------------------*/
    private boolean isSiteFull(int row, int col)
    {
        if (isOutOfBounds(row, col)) throw new IndexOutOfBoundsException();

        return this.topDownGraph.connected(flatten(row, col), TOP_AUX_SITE);
    }

    private boolean isSiteOpen(int row, int col)
    {
        if (isOutOfBounds(row, col)) {
            throw new IndexOutOfBoundsException();
        }
        else {
            return this.stateGrid[row][col];
        }
    }

    private void openSite(int row, int col)
    {
        if (isOutOfBounds(row, col)) {
            throw new IndexOutOfBoundsException();
        }

        if ( ! isSiteOpen(row, col)) {
            this.stateGrid[row][col] = OPEN;
            connectAdjacentOpenSites(row, col);
        }

        if (isTopBottomConnected(row, col)) {
            this.percolation = true;
        }
    }

    /**
     * @param row 0 <= row <= gridWidth - 1
     * @param col 0 <= row <= gridWidth - 1
     */
    private boolean isOutOfBounds(int row, int col)
    {
        return (row < 0 || row >= gridWidth || col < 0 || col >= gridWidth);
    }


    /**
     * Connects adjacent open sites to the site specified by the row and column coordinates.
     * @param row 0 <= row <= gridWidth - 1
     * @param col 0 <= row <= gridWidth - 1
     */
    private void connectAdjacentOpenSites(int row, int col)
    {
        int siteIndex = flatten(row, col);
        for(Shift direction : Shift.values()) {
            if ( isShiftOutOfBounds(row , col, direction)) {
                continue;
            }

            int shiftedRow = rowShift(row, direction);
            int shiftedCol = colShift(col, direction);
            if (isSiteOpen(shiftedRow, shiftedCol)) {
                topDownGraph.union(siteIndex, flatten(shiftedRow, shiftedCol));
                bottomUpGraph.union(siteIndex, flatten(shiftedRow, shiftedCol));
            }
        }

        if (row == 0) {
            topDownGraph.union(siteIndex, TOP_AUX_SITE);
        }

        if (row == this.bottomRow) {
            bottomUpGraph.union(siteIndex, BOTTOM_AUX_SITE);
        }
    }

    private boolean isTopBottomConnected(int row, int col)
    {
        int siteIndex = flatten(row, col);
        return topDownGraph.connected(siteIndex, TOP_AUX_SITE) && bottomUpGraph.connected(siteIndex, BOTTOM_AUX_SITE);
    }

    private boolean adjacentFull(int row, int col)
    {
        for(Shift direction : Shift.values()) {
            if ( isShiftOutOfBounds(row , col, direction)) {
                continue;
            }

            int shiftedRow = rowShift(row, direction);
            int shiftedCol = colShift(col, direction);
            if (isSiteFull(shiftedRow, shiftedCol)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param row 0 <= row <= gridWidth - 1
     * @param col 0 <= row <= gridWidth - 1
     * @param shift
     * @return
     */
    private boolean isShiftOutOfBounds(int row, int col, Shift shift)
    {
        switch(shift) {
            case UP:
                return isOutOfBounds(row-1, col);
            case DOWN:
                return isOutOfBounds(row+1, col);
            case LEFT:
                return isOutOfBounds(row, col-1);
            case RIGHT:
                return isOutOfBounds(row, col+1);
            default:
                throw new IndexOutOfBoundsException("Shift not specified.");
        }
    }


    private int colShift(int col, Shift shift)
    {
        if (shift == Shift.LEFT) {
            return col-1;
        }
        else if (shift == Shift.RIGHT) {
            return col+1;
        }
        else {
            return col;
        }
    }

    private int rowShift(int row, Shift shift)
    {
        if (shift == Shift.UP) {
            return row-1;
        }
        else if (shift == Shift.DOWN) {
            return row+1;
        }
        else {
            return row;
        }
    }

    private int flatten(int row, int col)
    {
        return gridWidth*row + col + NUM_AUX_SITES;
    }
}
